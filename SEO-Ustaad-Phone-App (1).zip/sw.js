/* SEO Ustaad service worker — makes the whole course work offline on a phone.
   Strategy: cache-first for the app shell and CDN libraries, network-first for
   API calls (which must always be live), and never cache a failed response.   */
const CACHE = "seo-ustaad-v1";
const SHELL = [
  "./",
  "./index.html",
  "./manifest.json",
  "./icon-192.png",
  "./icon-512.png",
  "https://cdn.tailwindcss.com",
  "https://cdnjs.cloudflare.com/ajax/libs/react/18.3.1/umd/react.production.min.js",
  "https://cdnjs.cloudflare.com/ajax/libs/react-dom/18.3.1/umd/react-dom.production.min.js",
  "https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.2/jspdf.umd.min.js"
];

self.addEventListener("install", (e)=>{
  e.waitUntil(
    caches.open(CACHE).then(c=>Promise.allSettled(SHELL.map(u=>c.add(u))))
          .then(()=>self.skipWaiting())
  );
});

self.addEventListener("activate", (e)=>{
  e.waitUntil(
    caches.keys().then(ks=>Promise.all(ks.filter(k=>k!==CACHE).map(k=>caches.delete(k))))
          .then(()=>self.clients.claim())
  );
});

self.addEventListener("fetch", (e)=>{
  const req = e.request;
  if(req.method !== "GET") return;
  const url = new URL(req.url);

  // AI and voice APIs must always go to the network — never serve a stale answer
  if(/generativelanguage\.googleapis\.com|api\.groq\.com|api\.elevenlabs\.io/.test(url.hostname)) return;

  e.respondWith(
    caches.match(req).then(hit=>{
      if(hit) return hit;
      return fetch(req).then(res=>{
        if(res && res.status === 200 && (res.type === "basic" || res.type === "cors")){
          const copy = res.clone();
          caches.open(CACHE).then(c=>c.put(req, copy));
        }
        return res;
      }).catch(()=> caches.match("./index.html"));
    })
  );
});
