# SEO Ustaad — Digital Marketing & SEO LMS

Bilingual (Urdu + English) SEO course app. Ek hi HTML file. Koi server nahi, koi database nahi, koi account nahi.

---

## 📦 Files

| File | Kya hai |
|---|---|
| **`index.html`** | **Poori app** — 316 KB |
| **`manifest.json`** | PWA manifest — install karne ke liye |
| **`sw.js`** | Service worker — **offline chalane ke liye** |
| `icon-192.png` / `icon-512.png` / `icon-maskable-512.png` | App icons |
| **`PHONE-SETUP.md`** | **Phone par poora course — install, tools, backup** |
| **`SETUP-GUIDE.md`** | Setup + deploy + APK + troubleshooting |
| **`DAILY-PLAN.md`** | **84 din ka rozana chain** — kya kab karna hai |
| `certificate-urdu-sample.pdf` | Urdu certificate ka namoona |
| `certificate-english-sample.pdf` | English certificate ka namoona |

---

## ⚡ 4 steps mein chalana

```
0.  SAAT files ek saath rakhein (index.html + manifest + sw.js + 3 icons)
1.  index.html par double-click            → app khul jayegi
2.  ⚙️ Settings → Gemini key paste → Save   → AI Tutor + Urdu awaaz chalu
3.  GitHub repo (Public) → index.html upload → Settings → Pages → ON
4.  pwabuilder.com → apna URL → Android → Generate → APK
```

Gemini key (mufat, koi card nahi): **https://aistudio.google.com/apikey**

Har step ki tafseel **`SETUP-GUIDE.md`** mein hai.

---

## 📚 App mein kya hai

| | |
|---|---|
| Nisab | 12 hafte — Google Digital Garage + DigiSkills merged |
| Lesson sections | 46 |
| Key terms | 44 |
| Quiz sawal | 60 — dono zubano mein wajah ke saath, 60% pass |
| Practice tasks | 12 |
| Video & Demo links | 33 |
| Free resource links | 25 |
| Templates | 4 — Audit checklist (40 points), Intent sheet (16 rows), Keyword planner (22 rows), 4 client pitches |
| Zubaan | English + اردو, poori RTL support |
| Themes | Dark / Light / Sepia + 4 text sizes |
| Awaaz | **Gemini TTS — Urdu jumla + English technical terms** (aam bol chaal) + Browser + ElevenLabs |
| AI Tutor | Gemini + Groq fallback, text + 🎤 mic |
| Certificate | PDF — English vector, Urdu canvas-rendered |
| Tools | 7 working tools — SERP preview, Schema generator, On-page checker, Keyword mixer, robots.txt, UTM, Quote calculator |
| 84-Day Plan | In-app tracker — aaj ka din, streak, har din checkbox, milestones |
| Offline | Service worker — lessons, quiz, tools sab internet ke baghair |
| Backup | Download / restore JSON — progress phone par le jayein |
| Progress | Browser ke localStorage mein, har student ka apna |

---

## 🔑 Keys — sab mufat

| Key | Kis liye | Zaroori? | Link |
|---|---|---|---|
| **Gemini** | AI Tutor + **asli Urdu awaaz** | ✅ Haan | https://aistudio.google.com/apikey |
| Groq | Gemini fail ho to backup | Optional | https://console.groq.com/keys |
| ElevenLabs ×2 | Studio-quality awaaz | Optional | https://elevenlabs.io/app/settings/api-keys |

Keys sirf **usi browser** mein rehti hain. Kahin upload nahi hotin.

> **Har student apni key banaye.** Aap apni key share karenge to sab ka istemaal aap ke quota se katega.

---

## 🛠️ Customize karna

`index.html` ko VS Code / Notepad++ mein kholein, `Ctrl+F` se dhoondein:

| Badalna hai | Dhoondein |
|---|---|
| App ka naam | `appName:` |
| Rang | `emerald-500` |
| Nisab | `CURRICULUM = [` |
| Quiz sawal | `quiz:[` (`a:0` = pehla option sahi) |
| Templates | `TEMPLATES = [` |
| Video links | `const WATCH = {` |
| Pass % | `pct >= 60` |
| Default theme | `theme: "dark"` |
| Gemini voice | `gemVoice: "Kore"` |

**Har tabdeeli ke baad:** file GitHub par dobara upload karein → 1 minute mein live. **APK khud update ho jati hai** (wo live URL load karti hai), dobara banane ki zarurat nahi.

---

## ⚠️ Jaan lein

1. **Progress har device par alag** — lekin ab ⚙️ → Download backup / Restore se manually le ja sakte hain.
2. **Certificate self-issued hai** — accredited nahi. Asal certificate ke liye students Google Digital Garage aur DigiSkills par khud enroll karein (links app mein hain).
3. **Gemini TTS models "preview" hain** — 3 models ka chain hai, sab fail hon to browser voice chal padti hai. App kabhi nahi rukti.
4. **Mic sirf Chrome/Edge** — Firefox support nahi karta.
5. **Urdu voice phone par** — Android → Settings → Text-to-speech → Urdu install karein (sirf browser voice ke liye; Gemini ko iski zarurat nahi).

---

## 🔗 Sources

- Google Search Central — https://developers.google.com/search/docs
- Google Digital Garage — https://grow.google/certificates/digital-marketing-ecommerce/
- DigiSkills.pk — https://digiskills.pk/
- Gemini TTS docs — https://ai.google.dev/gemini-api/docs/speech-generation
- web.dev Core Web Vitals — https://web.dev/articles/vitals
- PWABuilder — https://www.pwabuilder.com
- GitHub Pages — https://pages.github.com
