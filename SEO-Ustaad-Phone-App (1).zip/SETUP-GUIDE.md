# SEO Ustaad — Complete Setup Guide
### ایس ای او استاد — مکمل گائیڈ (Roman Urdu + English)

---

## Files kya kya hain

| File | Kya hai | Kya karna hai |
|---|---|---|
| `index.html` | **Poori app** — 250 KB, single file | GitHub par upload karein |
| `seo-ustaad-lms.html` | Wohi file, original naam se | Backup ke liye rakhein |
| `certificate-urdu-sample.pdf` | Urdu certificate ka namoona | Sirf dekhne ke liye |
| `certificate-english-sample.pdf` | English certificate ka namoona | Sirf dekhne ke liye |
| `SETUP-GUIDE.md` | Yeh guide | Padhne ke liye |

**Note:** `index.html` aur `seo-ustaad-lms.html` bilkul same file hain. GitHub Pages ko `index.html` naam chahiye hota hai, is liye pehle se rename kar diya hai.

---

# STEP 1 — Pehle apne computer par test karein (2 minute)

1. `index.html` file par **double-click** karein
2. Browser mein app khul jayegi
3. Neeche nav bar se check karein: Dashboard → Curriculum → Templates → Certificate

**Zaroori:** Internet ON hona chahiye pehli baar. App teen cheezein CDN se load karti hai (React, Tailwind, Urdu font). Ek baar load hone ke baad browser cache kar leta hai.

Agar khali safed screen aaye → internet check karein, phir `Ctrl+Shift+R` (hard refresh).

---

# STEP 2 — Free AI keys banayein (5 minute)

AI Tutor ke bina baqi poori app chalti hai. Lekin AI Tutor chalane ke liye key chahiye. **Dono free hain, credit card nahi.**

### 2a. Gemini key (primary)

1. Jayein: **https://aistudio.google.com/apikey**
2. Google account se sign in karein
3. **"Create API key"** button
4. Naya project select karein → **Create**
5. Key copy karein — `AIza...` se shuru hoti hai

### 2b. Groq key (backup — Gemini band ho to yeh chalti hai)

1. Jayein: **https://console.groq.com/keys**
2. Google ya GitHub se sign up
3. Left menu → **API Keys** → **Create API Key**
4. Key copy karein — `gsk_...` se shuru hoti hai

> ⚠️ Groq key sirf **ek baar** dikhti hai. Foran kahin save kar lein.

### 2c. App mein daalein

1. App kholein → upar dayein taraf **⚙️ gear icon**
2. "Google Gemini API key" box mein paste karein
3. "Groq API key" box mein paste karein
4. **Save** dabayein
5. AI Tutor tab par jayein → sawal poochein → test ho gaya

**Key kahan jati hai:** Sirf usi browser ke `localStorage` mein. Kahin upload nahi hoti, mere paas nahi aati, kisi server par nahi jati.

---

# STEP 2b — Reading comfort (colour + text size)

App mein **teen theme** hain. Header mein ☀️/🌙 button se turant badlein, ya ⚙️ Settings → **Reading comfort**:

| Theme | Kab behtar hai |
|---|---|
| 🌙 **Dark** | Raat, kam roshni |
| ☀️ **Light** | Din, tez roshni, projector |
| 📖 **Sepia** | **Lambi reading ke liye sab se aasan** — aankhon par zor nahi |

**Text size:** 4 options (A A A A). Sirf lesson ka matn, quiz aur AI jawab bade hote hain — buttons aur menu apni jagah rehte hain, layout nahi tootta. Urdu ke liye line-height bhi barh jati hai taake Nastaliq saaf rahe.

Dono choices browser mein save hoti hain. "Reset all progress" dabane par bhi theme aur size waise hi rehte hain.

---

# STEP 2c — Real accent Urdu awaaz

⚙️ Settings → **Urdu voice engine** — teen options hain:

| Engine | Awaaz | Key | Free quota |
|---|---|---|---|
| 🟣 **Gemini** ⭐ **default** | **Asli Urdu lehja**, qudrati | **Wohi Gemini key** jo AI Tutor ki hai | Bohot bara |
| ⚪ Browser | Mashini, robotic | Koi nahi | Unlimited |
| 🟪 ElevenLabs | Studio quality | Alag key chahiye | ~10,000 chars/mahina — bohot kam |

### Gemini voice (recommended — kuch karna hi nahi)

Aap ki Gemini key pehle se Settings mein hai, to **Urdu awaaz already asli lehje mein chal rahi hai**. Naya account nahi, nayi key nahi.

**20 voices** mein se chunein (Kore default hai). Zubaan khud pehchani jati hai — Urdu matn Urdu lehje mein parha jata hai, English English mein.

Awaaz badalne ke liye: ⚙️ → **Gemini voice** dropdown → **Test voice** → **Save**.

### ElevenLabs (sirf agar chahiye)

1. **https://elevenlabs.io/app/settings/api-keys** → 2 keys banayein
2. **https://elevenlabs.io/app/voice-library** → Voice ID copy karein
3. ⚙️ → ElevenLabs select → keys + Voice ID → **Test voice** → **Save**

> ⚠️ Free plan ~10,000 characters/mahina per key deta hai = **2–3 lessons**. Isi liye Gemini default hai.

### Bolne ka andaz — Urdu + English terms

⚙️ Settings → **Urdu bolne ka andaz** — do options:

| Andaz | Kaisa sunai deta hai |
|---|---|
| ⭐ **Aam bol chaal** (default) | "Yeh **page crawl** hota hai, phir **index** hota hai" — jaise Pakistani ustad asal mein bolta hai |
| Khalis Urdu | "Yeh safha kraaling hota hai, phir indeksing hota hai" — lafzi, magar koi aise bolta nahi |

**Aam bol chaal** mein 122 technical alfaz khud ba khud English mein bol diye jate hain — crawling, indexing, keyword, title tag, schema, backlink, Fiverr, Upwork waghera. Baqi jumla Urdu mein rehta hai.

Plural bhi theek hota hai: "لنکس" → "links", "کی ورڈز" → "keywords".

### Fallback — kabhi silence nahi

```
Urdu lesson par Play
   ↓
Chuna hua engine (Gemini / ElevenLabs)
   ↓ fail (quota, key ghalat, internet)
Browser ki apni awaaz  →  hamesha chalti hai ✅
```

Gemini ke andar bhi 3 models baari baari try hote hain (`gemini-3.1-flash-tts-preview` → `2.5-flash` → `2.5-pro`), aur ElevenLabs mein dono keys.

Play button ke paas **hamesha badge dikhta hai** — **Gemini**, **11L**, ya **Browser**.

> **Awaaz robotic lag rahi hai?** Badge dekhein. Agar **Browser** likha hai to natural voice chal hi nahi rahi — matlab Gemini key nahi dali, ya fail ho gayi. Neeche peela warning bhi wajah bata deta hai.

> **Note:** Natural voice sirf **Urdu** ke liye. English hamesha browser voice par — English voices har device mein pehle se achi hain, quota bachta hai.

---

# STEP 3 — GitHub Pages par live karein (10 minute)

Yeh step zaroori hai kyunki **APK banane ke liye ek live URL chahiye**.

### 3a. GitHub account

Agar nahi hai: **https://github.com/signup** — free hai.

### 3b. Repository banayein

1. Login ke baad upar dayein **`+`** → **New repository**
2. **Repository name:** `seo-ustaad` (jo marzi rakh lein)
3. **Public** select karein ✅ *(Private par free Pages nahi chalta)*
4. **Create repository**

### 3c. File upload

1. Naye repo mein **"uploading an existing file"** link par click
2. `index.html` ko drag & drop karein
3. Neeche **"Commit changes"** dabayein

### 3d. Pages ON karein

1. Upar **Settings** tab
2. Left menu mein neeche **Pages**
3. **Source:** `Deploy from a branch`
4. **Branch:** `main` → folder `/ (root)` → **Save**
5. **1–2 minute rukein**, phir page refresh karein

Upar aap ka URL aa jayega:

```
https://<aapka-username>.github.io/seo-ustaad/
```

Yeh URL kholein — app live hai. **Yeh URL copy kar lein**, agla step mein chahiye.

---

# STEP 4 — Android APK banayein (10 minute)

1. Jayein: **https://www.pwabuilder.com**
2. Apna GitHub Pages URL paste karein → **Start**
3. Scan complete hone dein (score dikhega)
4. **Android** card par → **Manifest / Package for stores**
5. Options mein:
   - **Package ID:** `com.seoustaad.app` (jo marzi, lekin unique)
   - **App name:** `SEO Ustaad`
   - **Generate service worker:** ✅ **tick karein** (isse offline chalega)
6. **Download** → ZIP milegi
7. ZIP kholein → andar **`.apk`** file hai

### APK phone par install

1. APK phone par bhejein (WhatsApp / USB / Google Drive)
2. Phone: **Settings → Security → Install unknown apps** → allow
3. APK par tap → Install

> **Play Store par dalna ho** to ZIP mein `.aab` file bhi hoti hai — Play Console (one-time $25) par wohi upload hoti hai. APK sirf direct sharing ke liye hai.

---

# STEP 5 — Students ise kaise use karenge

1. **Dashboard** — apna naam likhein, progress % dikhega
2. **Curriculum** — Week 1 se shuru, 12 hafte
3. Har lesson mein:
   - **🔊 Listen** — poora sabaq awaaz mein sunein (0.8x se 1.5x speed)
   - **Learning Objectives** — kya seekhna hai
   - **Lesson sections** — asal content
   - **Key Terms** — istilahat
   - **Practice Task** — asal kaam (copy button hai)
   - **Video & Demo** — official links + live YouTube search
   - **Mark Lesson Complete** — tick karein
4. **Quiz** tab — 5 sawal, har jawab ki wajah dono zubano mein. **60% pass**
5. **اردو / EN** button — poori app instantly badal jati hai (RTL layout ke saath)
6. **AI Tutor** — type karein ya 🎤 mic dabayein (English / Urdu / Roman Urdu)
7. **Templates** — 4 kaam ki sheets, sab copy ho sakti hain
8. **Certificate** — 12/12 mukammal hone par khulta hai, PDF download

**Progress kahan save hoti hai:** Har student ke apne browser mein. Har student ka apna progress. Server nahi, database nahi, account nahi.

---

# App mein kya kya hai — checklist

| Feature | Tafseel |
|---|---|
| 12 hafte ka nisab | Google Digital Garage + DigiSkills merged |
| Lesson sections | 46 |
| Key terms | 44 |
| Quiz sawal | 60 (5 per week), dono zubano mein wajah ke saath |
| Practice tasks | 12 |
| Video & Demo links | 33 |
| Free resource links | 25 |
| Templates | 4 (Audit checklist 40 points, Intent sheet 16 rows, Keyword planner 22 rows, 4 client pitches) |
| Zubaan | English + اردو, poori RTL support |
| Themes | Dark / Light / Sepia + 4 text sizes |
| Awaaz | Gemini TTS (asli Urdu lehja, 20 voices) + Browser TTS + ElevenLabs 2-key rotation |
| AI Tutor | Gemini + Groq fallback, text + mic |
| Certificate | PDF download — English vector, Urdu canvas-rendered |

---

# Customization — apne hisaab se badalna

File text editor (VS Code / Notepad++) mein kholein aur `Ctrl+F` se dhoondein:

| Kya badalna hai | Kya dhoondein | Kya karein |
|---|---|---|
| App ka naam | `appName:` | `en` aur `ur` dono badlein |
| Logo ke 2 haroof | `>SU<` | Apne initials |
| Rang (green) | `emerald-500` | `sky-500`, `violet-500`, waghera |
| Nisab ka content | `CURRICULUM = [` | Week objects edit karein |
| Quiz sawal | `quiz:[` | `a:0` matlab pehla option sahi hai |
| Templates | `TEMPLATES = [` | Rows / items badlein |
| Video links | `const WATCH = {` | Apne links |
| Pass percentage | `pct >= 60` | 60 ko badal dein |
| Default theme | `theme: "dark"` | `"light"` ya `"sepia"` |
| Default text size | `fs: "md"` | `"sm"`, `"lg"`, `"xl"` |
| Sepia ka rang | `data-theme="sepia"` | CSS values badlein |
| ElevenLabs model | `EL_MODEL` | `eleven_turbo_v2_5` (sasta, tez) |
| Default voice engine | `urVoice: "gemini"` | `"browser"` ya `"eleven"` |
| Gemini voice | `gemVoice: "Kore"` | 20 mein se koi |
| Default bolne ka andaz | `urStyle: "mix"` | `"pure"` |
| English terms ki list | `URDU_TO_EN = [` | apne alfaz shamil karein |
| Gemini TTS models | `GEM_TTS_MODELS` | order badlein |
| Urdu bolne ka andaz | `Neeche diye gaye Urdu matn` | style prompt badlein |
| Default voice | `EL_DEFAULT_VOICE` | apna voice ID |

**Har tabdeeli ke baad:** file save karein → GitHub par dobara upload karein (**"Upload files"** → same naam → commit) → 1 minute mein live ho jayegi. APK khud ba khud update ho jati hai kyunki wo live URL load karti hai.

---

# Masail aur hal (Troubleshooting)

| Masla | Wajah | Hal |
|---|---|---|
| Khali safed screen | Internet band tha pehli load par | Internet ON → `Ctrl+Shift+R` |
| AI Tutor jawab nahi deta | Key nahi dali | ⚙️ Settings → key paste → Save |
| "Gemini: API key not valid" | Key ghalat copy hui | Dobara copy karein, aage peeche space na ho |
| AI ne kaam karna band kar diya | Free quota khatam (rozana limit) | Groq key daal dein — khud switch ho jayegi |
| Urdu awaaz nahi aati | Phone mein `ur-PK` voice nahi | Android: Settings → Text-to-speech → Urdu install karein |
| Mic button nahi dikhta | Browser support nahi karta | Chrome ya Edge use karein (Firefox mein nahi chalta) |
| PDF download nahi hota | jsPDF load nahi hui | Internet ON karke dobara try karein |
| Urdu awaaz robotic hai | Badge par **Browser** likha hai | ⚙️ → **Gemini** select + Gemini key dalein |
| Technical alfaz ajeeb lag rahe hain | Khalis Urdu andaz chala hua hai | ⚙️ → **Aam bol chaal** select karein |
| Peela warning aa raha hai | Natural voice fail hui | Warning mein wajah likhi hai — key ya internet check karein |
| Gemini TTS: "model not found" | Preview model us key par nahi | Khud agle model par chala jata hai; kuch na karein |
| Gemini voice pasand nahi | Voice ka farq | ⚙️ → Gemini voice dropdown → dusri chunein → Test |
| Test voice: "quota_exceeded" | Mahane ke 10,000 credits khatam | Dusri key dalein ya agle mahine ka intezar |
| Test voice: "Invalid API key" | Key ghalat copy hui | Dobara copy karein, `sk_` se shuru honi chahiye |
| 11L badge nahi dikhta | ElevenLabs fail hui, browser voice chali | Settings → Test voice se wajah dekhein |
| Theme wapas dark ho gaya | Browser data clear hua | Dobara select karein |
| Progress gayab ho gayi | Browser history/data clear hua | Dobara shuru — data sirf browser mein hota hai |
| GitHub Pages 404 | 1-2 minute nahi guzre, ya repo private hai | Rukein; repo **Public** karein |
| PWABuilder score kam | Normal hai | Score se farq nahi parta, APK phir bhi banta hai |

---

# Zaroori baatein (limitations — pehle jaan lein)

1. **Progress har device par alag hai.** Ek student ke phone aur laptop ka progress alag rahega. Sync ke liye backend chahiye — abhi nahi hai.
2. **Certificate self-issued hai.** Yeh koi accredited certificate nahi. Asal accredited certificate ke liye students ko Google Digital Garage aur DigiSkills par khud enroll karna hoga — links app ke "Free Resources" mein hain.
3. **API key har student ki apni.** Aap apni key share karenge to sab ka istemaal aap ke quota se katega aur jaldi khatam ho jayega. Har student apni banaye — 2 minute ka kaam hai.
4. **Urdu certificate PDF image-based hai** (text select nahi hoga). English wala vector hai. Yeh is liye ke Nastaliq shaping PDF fonts mein nahi hoti.
5. **Gemini TTS models "preview" hain** — Google inhe badal sakta hai. App teen models baari baari try karti hai, aur sab fail hon to browser voice par chali jati hai, is liye app kabhi nahi rukti.
6. **ElevenLabs free plan bohot chhota hai** — ~10,000 characters/mahina per key (2–3 lessons). Yeh app ki nahi, ElevenLabs ki limit hai. Rozana istemaal ke liye ya to paid plan lein ya browser voice par rahein — is liye browser voice hi default hai.
7. **Video links live searches hain**, hardcoded video IDs nahi. Wajah: individual videos delete ho jate hain aur 6 mahine baad students ko broken players milte. Search links kabhi nahi marte.

---

# Web references

**Free API keys**
- Google AI Studio — https://aistudio.google.com/apikey
- Groq Console — https://console.groq.com/keys
- Gemini TTS docs — https://ai.google.dev/gemini-api/docs/speech-generation
- ElevenLabs API keys — https://elevenlabs.io/app/settings/api-keys
- ElevenLabs Voice Library — https://elevenlabs.io/app/voice-library
- ElevenLabs TTS API docs — https://elevenlabs.io/docs/api-reference/text-to-speech/convert

**Deployment**
- GitHub Pages — https://pages.github.com
- PWABuilder — https://www.pwabuilder.com

**Nisab ka maakhaz (curriculum sources)**
- Google Search Central — https://developers.google.com/search/docs
- Google Digital Garage — https://grow.google/certificates/digital-marketing-ecommerce/
- DigiSkills.pk — https://digiskills.pk/
- web.dev Core Web Vitals — https://web.dev/articles/vitals
- Google Search Quality Rater Guidelines — https://guidelines.raterhub.com/searchqualityevaluatorguidelines.pdf
- Schema.org — https://schema.org/docs/full.html

**Freelancing**
- Fiverr Help — https://help.fiverr.com/hc/en-us
- Upwork Resources — https://www.upwork.com/resources/
- PSEB — https://www.pseb.org.pk/

---

# 4 steps mein poora kaam

```
1. index.html double-click → test
2. Gemini + Groq keys → ⚙️ Settings mein paste
   (Urdu awaaz already asli lehje mein — wohi Gemini key use hoti hai)
3. GitHub repo (Public) → upload index.html → Settings → Pages → ON
4. pwabuilder.com → URL paste → Android → Generate → APK
```

Bas. Ho gaya.
