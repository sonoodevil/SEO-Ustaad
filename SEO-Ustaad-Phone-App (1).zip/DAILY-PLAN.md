# SEO Ustaad — Daily Chain Process
### روزانہ کا نظام — 84 din mein basic se expert

---

## Pehle yeh samajh lein

App mein **12 hafte** hain. Har hafta = **7 din ka fixed chain**. Rozana **90 minute**. Bas.

Chain ka matlab: har din ka kaam agle din ke kaam ko feed karta hai. Ek din chhoot jaye to us din ko skip mat karein — **agle din shift kar dein**, warna kaam adhoora reh jata hai.

---

# 🔁 ROZANA KA CHAIN — 90 minute

Yeh **har din wohi hai**. Sirf content badalta hai.

| # | Kaam | Waqt | App mein kahan |
|---|---|---|---|
| **1** | **Revise** — kal ki ghaltiyan + key terms | 10 min | Pichla lesson → Key Terms |
| **2** | **Seekho** — naya hissa, Listen + parho | 30 min | Lesson → 🔊 Listen |
| **3** | **Test** — quiz ya self-check | 15 min | Quiz tab |
| **4** | **Karo** — asal site par practice | 30 min | Practice Task + Templates |
| **5** | **Likho** — log + kal ka plan | 5 min | Copybook / sheet |

> **Sab se ahem qadam #4 hai.** Sirf parhne se koi client nahi milta. Har din **kisi asal website par** kaam karna hai — apni, dost ki, ya koi bhi Pakistani business ki site jo aap Google par dhoond lein.

---

# 📅 HAFTAY KA CHAIN — 7 din ka pattern

Har hafte **yehi 7 din** dohrayein, sirf hafte ka mauzu badlega.

| Din | Naam | Kya karna hai | Nateeja |
|---|---|---|---|
| **1** | **Samjho** | Lesson kholein → Objectives + section 1–2 → Listen | Bunyaad ban gayi |
| **2** | **Poora karo** | Section 3–4 + Key Terms + Video & Demo links | Mauzu mukammal |
| **3** | **Jaanchо** | Quiz dein → ghalat jawabon ki wajah parhein → dobara quiz | 60%+ pass |
| **4** | **Practice A** | Practice Task shuru → asal site par | Adha kaam |
| **5** | **Practice B** | Practice Task khatam + related Template bharein | Poora kaam |
| **6** | **Gehrai** | AI Tutor se 5 sawal → jo samajh na aya → dobara | Shak khatam |
| **7** | **Sameto** | Hafte ka review + portfolio mein entry + Mark Complete ✅ | Sabooт tayyar |

**Din 7 par 3 cheezein zaroori:**
1. App mein **Mark Lesson Complete** dabayein (progress % barhega)
2. Apne portfolio folder mein us hafte ka **screenshot + 3 line note** rakhein
3. Agle hafte ka lesson **preview** kar lein (5 min)

---

# 📆 12 HAFTE — kya kab

## MONTH 1 — Bunyaad (Din 1–28)

| Hafta | Mauzu | Din 7 tak aap ke paas kya hoga |
|---|---|---|
| **1** | Crawling, Indexing, Ranking | Ek site ka `site:` count + robots.txt ka poora jaiza |
| **2** | Search Intent | 10 keywords ki intent mapping sheet (bhari hui) |
| **3** | Long-Tail Keyword Research | 50 keywords, 5 clusters mein — sirf mufat tools se |
| **4** | Competitor Gap Analysis | 3 competitors ke sitemaps + agle 8 article titles |

**Month 1 ka nateeja:** Aap ek site ka keyword plan bana sakte hain. **Yeh pehli service hai jo aap bech sakte hain.**

## MONTH 2 — Amal (Din 29–56)

| Hafta | Mauzu | Din 7 tak aap ke paas kya hoga |
|---|---|---|
| **5** | On-Page (Title, URL, Meta, Alt) | 10 safhaat ka on-page audit + 3 theek kiye hue |
| **6** | Technical SEO + Core Web Vitals | PageSpeed report + top 3 masail ki list |
| **7** | Schema Markup (JSON-LD) | LocalBusiness + Article schema, 0 errors |
| **8** | Local SEO + Google Business Profile | Kisi Lahore business ka GBP audit + 1 hafte ka plan |

**Month 2 ka nateeja:** Aap **paid audit** de sakte hain. Fiverr par $50–150 ki gig yahin banti hai.

## MONTH 3 — Kamai (Din 57–84)

| Hafta | Mauzu | Din 7 tak aap ke paas kya hoga |
|---|---|---|
| **9** | AI Content + E-E-A-T | 1 mazmoon jismein aap ka apna data + screenshot ho |
| **10** | GA4 + Search Console | Looker Studio ki 1-safha client report |
| **11** | Off-Page + Link Building | 25 prospects ki sheet + 5 bheji hui emails |
| **12** | Fiverr / Upwork / Proposals | **Live gig + 3 bheje hue proposals** |

**Month 3 ka nateeja:** Gig live hai, proposals ja rahe hain, report ka namoona tayyar hai.

---

# 🎯 CHECKPOINTS — yahan ruk kar jaanchein

Agar checkpoint pass na ho, **aage mat barhein**. Us hafte ko dobara karein.

| Din | Checkpoint | Pass ka matlab |
|---|---|---|
| **28** | Month 1 mukammal | 4/4 quiz pass + 50 keywords ki sheet bhari hui |
| **56** | Month 2 mukammal | 8/8 quiz pass + 1 poora audit likha hua |
| **70** | Portfolio | 3 case studies (pehle/baad ke screenshots ke saath) |
| **84** | **Launch** | Gig live + 3 proposals bheje + certificate download |

---

# 🌅 DIN KA NAQSHA — waqt ka intezam

Teen options — jo aap ki zindagi mein fit ho:

### A. Subah wala (behtareen — dimagh taza hota hai)
```
05:30 – 06:00   Revise + naya lesson (Listen)
06:00 – 06:30   Lesson poora + quiz
        [ din bhar ka kaam / university ]
21:00 – 21:30   Practice task asal site par
```

### B. Raat wala
```
21:00 – 21:15   Revise
21:15 – 21:50   Lesson + Listen
21:50 – 22:05   Quiz
22:05 – 22:35   Practice
```

### C. Sirf weekend (job wale log)
```
Hafte mein 2 din × 4 ghante = 1 hafte ka content
Yaani 12 hafte ka course ~24 hafton mein
```

> **Sacchi baat:** Rozana 90 minute × 84 din = **126 ghante**. Yeh koi shortcut nahi. Jo log 2 hafte mein "SEO expert" ka wada karte hain, wo jhoot bolte hain.

---

# 📓 ROZANA KA LOG — yehi asal raaz hai

Har din 5 minute nikaal kar likhein. Ek copy, ek Excel sheet, ya phone ka notes app — jo bhi.

```
Tareekh: ____________       Din # ____  /  Hafta # ____

1. Aaj kya seekha (1 line):
   _______________________________________________

2. Kis site par practice ki:
   _______________________________________________

3. Quiz score:  ____ %      Kaunse sawal ghalat:  ____________

4. Kya samajh nahi aya (kal AI Tutor se poochna hai):
   _______________________________________________

5. Kal ka pehla kaam:
   _______________________________________________
```

**Yeh log kyun zaroori hai:** 84 din baad jab client poochega "aap ne kya kiya hai?", to yehi log aap ka **portfolio** ban jayega. Aur point #4 se AI Tutor ka istemaal 10 guna behtar ho jata hai — random sawal ke bajaye asal masla poochte hain.

---

# 🔗 PORTFOLIO CHAIN — hafta 1 se shuru

Har hafte ke din 7 par, ek folder mein yeh rakhein:

```
📁 SEO-Portfolio/
   📁 Week-01-Crawling/
      screenshot-site-search.png
      robots-txt-notes.txt
      3-line-summary.txt
   📁 Week-02-Intent/
      intent-mapping-sheet.csv     ← app ke template se Copy karke
      ...
```

Hafta 12 tak aap ke paas **12 folder** honge. Jab Fiverr gig ya Upwork proposal banayenge, to yeh **sabot** hai — sirf dawa nahi.

App ke **Templates** tab se har sheet **Copy** karke Excel/Google Sheets mein paste kar sakte hain.

---

# 👨‍🏫 AGAR AAP DUSRON KO PARHA RAHE HAIN

Aap ka apna rozana chain (students ke liye):

| Waqt | Kaam |
|---|---|
| **Subah 15 min** | WhatsApp group mein aaj ka din + task bhejein |
| **Dopahar 10 min** | Kal ke quiz scores maangein (screenshot) |
| **Shaam 20 min** | 2–3 students ke practice kaam par feedback |
| **Hafte mein 1 din 60 min** | Live session — us hafte ke ghalat quiz sawal samjhayein |

**Batch chalane ka tareeqa:**
1. Sab students ko APK bhejein (ek hi file, sab ke liye)
2. Har student **apni** Gemini key banaye — 2 minute ka kaam, aur aap ka quota nahi katega
3. Har hafte ke akhir mein sab se **progress screenshot** maangein (app mein % dikhta hai)
4. Din 28 / 56 / 84 par checkpoint test — jo pass na ho, uska hafta dobara

---

# ⚡ CHOTE MASAIL — chain toot jaye to

| Masla | Hal |
|---|---|
| **Ek din chhoot gaya** | Agle din shift karein. Skip **mat** karein. |
| **3+ din chhoot gaye** | Poora hafta dobara shuru — adhoori bunyaad par agla hafta nahi banta |
| **Quiz mein 60% nahi aa raha** | Us lesson ko dobara **Listen** karein, phir quiz. Aage mat barhein. |
| **Practice ke liye site nahi hai** | Google par "restaurant lahore" search karein — koi bhi chhoti site chunein, uska audit karein |
| **Waqt nahi mil raha** | 90 min ko 45 min kar dein aur 24 hafte lein — magar **rozana** karein. Consistency > lambe session. |
| **Motivation khatam** | App ka progress bar dekhein. 30% par pohanch gaye to sab se mushkil hissa guzar chuka hai. |

---

# ✅ AAJ SE SHURU KARNE KA TAREEQA

```
Aaj (Din 0)
  1. index.html kholein → apna naam dalein
  2. ⚙️ Settings → Gemini key paste → Save
  3. Theme aur text size apni pasand ka chunein
  4. Log copy/sheet bana lein
  5. Alarm set karein — rozana wohi waqt

Kal (Din 1)
  Week 1 kholein → Listen dabayein → chain shuru
```

Bas. **84 din baad certificate download hoga aur gig live hogi.**

---

## Web references

- Google Digital Garage — https://grow.google/certificates/digital-marketing-ecommerce/
- DigiSkills.pk (mufat, Urdu) — https://digiskills.pk/
- Google Search Central — https://developers.google.com/search/docs
- Google Search Console — https://search.google.com/search-console/about
- PageSpeed Insights — https://pagespeed.web.dev/
- Fiverr Seller Help — https://help.fiverr.com/hc/en-us
- Upwork Resources — https://www.upwork.com/resources/
- PSEB (freelancer registration) — https://www.pseb.org.pk/
